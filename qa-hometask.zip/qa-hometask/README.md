# QA Home task

Spring boot application to write test against

## Prerequisites
* Java 11

## How to run application

```
./gradlew bootRun
```

Application will be available at `localhost:8080`

### Extra notes
Application does have Swagger available at `localhost:8080/swagger-ui.html`

### How to bundle/unbundle source code
Checkout available code from the provided bundle file:

```shell
git clone -b master hometask-initial-setup.bundle hometask
```

Once tests are added, bundle source code:  
```shell
git bundle create hometask.bundle HEAD master
``` 