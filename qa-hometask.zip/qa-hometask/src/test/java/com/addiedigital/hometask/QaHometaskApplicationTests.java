package com.addiedigital.hometask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaHometaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
