package com.addiedigital.hometask.service;

import com.addiedigital.hometask.api.product.ProductRequestDto;
import com.addiedigital.hometask.entity.Product;
import com.addiedigital.hometask.repository.ProductRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
@Slf4j
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getProducts() {
        return productRepository.findAll();
    }

    public Product addProduct(ProductRequestDto productRequestDto) {
        Product product = new Product(productRequestDto.getName(), Float.parseFloat(productRequestDto.getPrice()), productRequestDto.getDescription());
        return productRepository.save(product);
    }

    public Product getProductById(long id) {
        return productRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Product not found"));
    }

    public Product editProduct(long id, ProductRequestDto productRequestDto) {
        Product productById = getProductById(id);
        productById.setId(productById.getId());
        productById.setName(productRequestDto.getName());
        productById.setPrice(Float.parseFloat(productRequestDto.getPrice()) * 0.1F);
        productById.setDescription(productRequestDto.getDescription());
        return productRepository.save(productById);
    }

    public void deleteProduct(Long id) {
        Product productById = getProductById(id);
        productRepository.delete(productById);
    }
}
