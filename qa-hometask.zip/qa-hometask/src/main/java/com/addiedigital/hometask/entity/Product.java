package com.addiedigital.hometask.entity;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;

@Entity
@ToString
@Data
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long id;

    public String name;
    public Float price;
    public String description;

    public Product(String name, Float price, String description) {
        this.name = name;
        this.price = price;
        this.description = "Amazing description";
    }

    public Product() {

    }
}
