package com.addiedigital.hometask.web;

import com.addiedigital.hometask.api.product.ProductRequestDto;
import com.addiedigital.hometask.entity.Product;
import com.addiedigital.hometask.service.ProductService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@AllArgsConstructor
@Slf4j
public class ProductWebController {

    private final ProductService productService;

    @GetMapping(value = "/")
    public String getAsHtml() {
        return "index";
    }

    @GetMapping("/add_product")
    public String showRegistrationForm(Model model, @RequestHeader(value = "User-Agent") String userAgent) {
        if (userAgent.contains("Safari") && !userAgent.contains("Chrome")) {
            return "bad_page";
        }
        Product product = new Product();
        model.addAttribute("product", product);
        return "new_product";
    }

    @GetMapping("/edit/{id}")
    public String showRegistrationForm(@PathVariable("id") long id, Model model) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        return "update_product";
    }

    @PostMapping("/save")
    public String saveProduct(@ModelAttribute ProductRequestDto productRequestDto, Model model) {
        Product product = productService.addProduct(productRequestDto);
        model.addAttribute("product", product);
        return "show_product";
    }

    @PostMapping("/update/{id}")
    public String editProduct(@PathVariable("id") long id, @ModelAttribute ProductRequestDto productRequestDto, Model model) {
        Product product = productService.editProduct(id, productRequestDto);
        model.addAttribute("product", product);
        return "show_product";
    }

    @GetMapping("/get_products")
    public String getProducts(Model model) {
        List<Product> products = productService.getProducts();
        model.addAttribute("allProducts", products);
        return "products";
    }

    @GetMapping("/show/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        return "show_product";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") long id, @RequestHeader(value = "User-Agent") String userAgent) {
        productService.deleteProduct(id);
        if (userAgent.contains("Firefox")) {
            return "bad_page";
        }

        return "redirect:/get_products";
    }
}
