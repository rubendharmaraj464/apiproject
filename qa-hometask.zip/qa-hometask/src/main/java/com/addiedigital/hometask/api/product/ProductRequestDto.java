package com.addiedigital.hometask.api.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductRequestDto {

    private String name;
    private String price;
    private String description;

}
