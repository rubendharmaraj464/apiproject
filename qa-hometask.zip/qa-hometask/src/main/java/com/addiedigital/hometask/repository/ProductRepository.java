package com.addiedigital.hometask.repository;

import com.addiedigital.hometask.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
